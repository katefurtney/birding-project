
fetch('./bird_data_simple.json')
    .then(response => response.json())
    .then(data => {
        console.log(data)

        const table_element = document.getElementById("bird_data");
        //add headers to result
        let result = `<tr>
                        <th>Species</th>
                        <th>First Seen</th>
                        <th>Country</th>
                    </tr>`;

        data.forEach(row => {
            // result += JSON.stringify(row)
            result += `<tr>`;
            result += `<td>${row.Species}</td>`;
            result += `<td>${row.Year}</td>`;
            result += `<td>${row.Country}</td>`;
            result += `</tr>`;
        })

        table_element.innerHTML = result;
    })